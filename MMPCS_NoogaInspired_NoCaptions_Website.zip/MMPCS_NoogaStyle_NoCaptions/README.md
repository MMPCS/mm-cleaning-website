# M&M Professional Cleaning Services Website

Upload all files and folders in this package to your GitHub repository.

## GitHub Pages setup
Settings → Pages → Source: Deploy from a branch → Branch: main → Folder: /(root) → Save

## FormSubmit setup
The contact form sends to mindie@mmpfcs.com through FormSubmit. The first time the form is submitted, FormSubmit may send a confirmation email to activate the address.
