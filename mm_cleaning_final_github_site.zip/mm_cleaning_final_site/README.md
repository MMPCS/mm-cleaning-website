# M&M Professional Cleaning Services Website

Upload the contents of this folder to a GitHub repository, then turn on GitHub Pages:

Settings → Pages → Branch: main → /root → Save

Replace `your-email@example.com` in `index.html` with your business email when ready.
